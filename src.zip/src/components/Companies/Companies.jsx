import React, { useEffect } from 'react';
import './Companies.css';
const Companies = () => {
  
  return (
   
  
    <section className='c-warpper'>
      <div className="paddings innerWidth flexCenter c-container">
        <img src='cd.png' alt=''/>
        <img src='r.png' alt=''/>
        <img src='ddd.png' alt=''/>
        
      </div>
    </section>
  )
}

export default Companies
